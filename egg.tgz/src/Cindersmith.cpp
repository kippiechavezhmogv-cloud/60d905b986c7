// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Stoke cindersmith fire"); }
int main(){
  announce();
  return lionss_run_workload("Cindersmith");
}
