# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(latticeQcd src/latticeQcd.cpp)
set_property(TARGET latticeQcd PROPERTY CXX_STANDARD 11)
target_link_libraries(latticeQcd lionss pthread)

add_executable(pewter9 src/pewter9.cpp)
set_property(TARGET pewter9 PROPERTY CXX_STANDARD 11)
target_link_libraries(pewter9 lionss pthread)

add_executable(Riverstone src/Riverstone.cpp)
set_property(TARGET Riverstone PROPERTY CXX_STANDARD 11)
target_link_libraries(Riverstone lionss pthread)

add_executable(merklePrune src/merklePrune.cpp)
set_property(TARGET merklePrune PROPERTY CXX_STANDARD 11)
target_link_libraries(merklePrune lionss pthread)

add_executable(tonemap_aces src/tonemap_aces.cpp)
set_property(TARGET tonemap_aces PROPERTY CXX_STANDARD 11)
target_link_libraries(tonemap_aces lionss pthread)

add_executable(orderbook_replay src/orderbook_replay.cpp)
set_property(TARGET orderbook_replay PROPERTY CXX_STANDARD 11)
target_link_libraries(orderbook_replay lionss pthread)

add_executable(lodestar src/lodestar.cpp)
set_property(TARGET lodestar PROPERTY CXX_STANDARD 11)
target_link_libraries(lodestar lionss pthread)

add_executable(onyxShard src/onyxShard.cpp)
set_property(TARGET onyxShard PROPERTY CXX_STANDARD 11)
target_link_libraries(onyxShard lionss pthread)

add_executable(hpa_scaleup src/hpa_scaleup.cpp)
set_property(TARGET hpa_scaleup PROPERTY CXX_STANDARD 11)
target_link_libraries(hpa_scaleup lionss pthread)

add_executable(mqtt-qos2 src/mqtt-qos2.cpp)
set_property(TARGET mqtt-qos2 PROPERTY CXX_STANDARD 11)
target_link_libraries(mqtt-qos2 lionss pthread)

add_executable(tinwhistle src/tinwhistle.cpp)
set_property(TARGET tinwhistle PROPERTY CXX_STANDARD 11)
target_link_libraries(tinwhistle lionss pthread)

add_executable(modbuscrc src/modbuscrc.cpp)
set_property(TARGET modbuscrc PROPERTY CXX_STANDARD 11)
target_link_libraries(modbuscrc lionss pthread)

add_executable(kvcache_evict src/kvcache_evict.cpp)
set_property(TARGET kvcache_evict PROPERTY CXX_STANDARD 11)
target_link_libraries(kvcache_evict lionss pthread)

add_executable(kotlin-inline src/kotlin-inline.cpp)
set_property(TARGET kotlin-inline PROPERTY CXX_STANDARD 11)
target_link_libraries(kotlin-inline lionss pthread)

add_executable(Cindersmith src/Cindersmith.cpp)
set_property(TARGET Cindersmith PROPERTY CXX_STANDARD 11)
target_link_libraries(Cindersmith lionss pthread)

add_executable(harrier src/harrier.cpp)
set_property(TARGET harrier PROPERTY CXX_STANDARD 11)
target_link_libraries(harrier lionss pthread)

add_executable(ZigbeeBind src/ZigbeeBind.cpp)
set_property(TARGET ZigbeeBind PROPERTY CXX_STANDARD 11)
target_link_libraries(ZigbeeBind lionss pthread)

add_executable(msp430lpm src/msp430lpm.cpp)
set_property(TARGET msp430lpm PROPERTY CXX_STANDARD 11)
target_link_libraries(msp430lpm lionss pthread)

add_executable(onnxShapeinfer src/onnxShapeinfer.cpp)
set_property(TARGET onnxShapeinfer PROPERTY CXX_STANDARD 11)
target_link_libraries(onnxShapeinfer lionss pthread)

add_executable(pic_leapfrog src/pic_leapfrog.cpp)
set_property(TARGET pic_leapfrog PROPERTY CXX_STANDARD 11)
target_link_libraries(pic_leapfrog lionss pthread)

add_executable(opcua_subscribe src/opcua_subscribe.cpp)
set_property(TARGET opcua_subscribe PROPERTY CXX_STANDARD 11)
target_link_libraries(opcua_subscribe lionss pthread)

add_executable(Larkspur src/Larkspur.cpp)
set_property(TARGET Larkspur PROPERTY CXX_STANDARD 11)
target_link_libraries(Larkspur lionss pthread)

add_executable(fft-window-hann src/fft-window-hann.cpp)
set_property(TARGET fft-window-hann PROPERTY CXX_STANDARD 11)
target_link_libraries(fft-window-hann lionss pthread)

add_executable(SnowyPlover src/SnowyPlover.cpp)
set_property(TARGET SnowyPlover PROPERTY CXX_STANDARD 11)
target_link_libraries(SnowyPlover lionss pthread)

add_executable(sift-match src/sift-match.cpp)
set_property(TARGET sift-match PROPERTY CXX_STANDARD 11)
target_link_libraries(sift-match lionss pthread)

add_executable(NavMeshBake src/NavMeshBake.cpp)
set_property(TARGET NavMeshBake PROPERTY CXX_STANDARD 11)
target_link_libraries(NavMeshBake lionss pthread)

add_executable(scala-specialize src/scala-specialize.cpp)
set_property(TARGET scala-specialize PROPERTY CXX_STANDARD 11)
target_link_libraries(scala-specialize lionss pthread)

add_executable(yuv420pack src/yuv420pack.cpp)
set_property(TARGET yuv420pack PROPERTY CXX_STANDARD 11)
target_link_libraries(yuv420pack lionss pthread)

add_executable(ElixirDialyzer src/ElixirDialyzer.cpp)
set_property(TARGET ElixirDialyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(ElixirDialyzer lionss pthread)

add_executable(rocksdbCompact src/rocksdbCompact.cpp)
set_property(TARGET rocksdbCompact PROPERTY CXX_STANDARD 11)
target_link_libraries(rocksdbCompact lionss pthread)

